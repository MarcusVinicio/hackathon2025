#!/bin/bash
set -euo pipefail

ORIG_DIR=$(pwd)

echo "=== Iniciando deploy da esteira DevSecOps ==="

############################################
# 1. Instalar Tekton
############################################
echo "=== 📦 Instalando Tekton ==="
sh getting-started/hackathon/scripts/install-tekton.sh

############################################
# 2. Namespaces
############################################
echo "=== Criando namespaces ==="
kubectl create namespace des || true
kubectl create namespace prd || true
kubectl create namespace observability || true

############################################
# 3. Registry interno HTTPS
############################################
echo "=== Criando registry interno HTTPS ==="
kubectl apply -f getting-started/hackathon/pvc/registry-pvc.yaml -n des

mkdir -p ~/certs && cd ~/certs
openssl genrsa -out ca.key 4096
openssl req -x509 -new -nodes -key ca.key -sha256 -days 3650 -out ca.crt -subj "/CN=Custom Registry CA"
openssl genrsa -out registry.key 4096
openssl req -new -key registry.key -out registry.csr -subj "/CN=registry.des.svc.cluster.local"
openssl x509 -req -in registry.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out registry.crt -days 365 -sha256
kubectl -n des create secret tls registry-tls --cert=registry.crt --key=registry.key --dry-run=client -o yaml | kubectl apply -f -
kubectl -n des create secret generic registry-ca --from-file=ca.crt=$HOME/certs/ca.crt --dry-run=client -o yaml | kubectl apply -f -

cd "$ORIG_DIR"

kubectl -n des apply -f getting-started/hackathon/deployments/registry-deployment.yaml

############################################
# 4. Runners CI/CD
############################################
echo "=== Buildando runners CI/CD ==="
kubectl apply -f getting-started/hackathon/rbac/rbac-cd.yaml

kubectl create configmap dockerfile-app \
  --from-file=Dockerfile.app=./getting-started/hackathon/dockerfiles/Dockerfile.app -n des --dry-run=client -o yaml | kubectl apply -f -

kubectl -n des create configmap quarkus-manifest \
  --from-file=quarkus-manifest.yaml=./getting-started/hackathon/deployments/quarkus-manifest.yaml --dry-run=client -o yaml | kubectl apply -f -

docker build -t localhost:32000/ci-runner:latest -f getting-started/hackathon/dockerfiles/Dockerfile.ci .
docker push localhost:32000/ci-runner:latest

docker build -t localhost:32000/cd-runner:latest -f getting-started/hackathon/dockerfiles/Dockerfile.cd .
docker push localhost:32000/cd-runner:latest

kubectl apply -f getting-started/hackathon/rbac/rbac-cosign.yaml
kubectl apply -f getting-started/hackathon/pvc/artifacts-pvc.yaml -n des

kubectl apply -f getting-started/hackathon/deployments/prd/quarkus-manifest-prd.yaml
kubectl apply -f getting-started/hackathon/deployments/prd/ingress-prd.yaml

############################################
# 5. Observabilidade (Grafana + Loki + Promtail)
############################################

echo "=== Configurando observabilidade ==="
kubectl apply -f getting-started/hackathon/rbac/promtail-rbac.yaml 
kubectl apply -f getting-started/hackathon/observability/grafana-dashboards-configmap.yaml -n observability
kubectl apply -f getting-started/hackathon/observability/observability-pvc.yaml -n observability
kubectl apply -f getting-started/hackathon/observability/loki-configmap.yaml -n observability
kubectl apply -f getting-started/hackathon/observability/loki-deploy.yaml -n observability
kubectl apply -f getting-started/hackathon/observability/promtail-configmap.yaml -n observability
kubectl apply -f getting-started/hackathon/observability/promtail-daemonset.yaml -n observability
kubectl apply -f getting-started/hackathon/observability/grafana-configmap.yaml -n observability
kubectl apply -f getting-started/hackathon/observability/grafana-deploy.yaml -n observability

############################################
# 6. Verificação de Pods
############################################
echo "=== Verificando pods ==="
kubectl get pods -n observability
kubectl get pods -n des

############################################
# 7. Pipeline CI/CD
############################################

echo "=== Criando pipeline CI/CD ==="

kubectl delete pipelineruns --all -n des --ignore-not-found
kubectl delete taskruns --all -n des --ignore-not-found

kubectl apply -f getting-started/hackathon/pipeline.yaml -n des
kubectl apply -f getting-started/hackathon/pipeline-run.yaml -n des

echo "=== Rodando pipeline"

PIPELINERUN_NAME=$(kubectl get pipelinerun -n des -o jsonpath='{.items[0].metadata.name}')


while true; do
  STATUS=$(kubectl get pipelinerun $PIPELINERUN_NAME -n des -o jsonpath='{.status.conditions[0].status}' 2>/dev/null || echo "Unknown")
  
  echo "PipelineRun: $PIPELINERUN_NAME | Status: $STATUS"
  kubectl get taskruns -n des --selector=tekton.dev/pipelineRun=$PIPELINERUN_NAME
  
  if [ "$STATUS" = "True" ]; then
    echo "Pipeline finalizado com sucesso!"
    break
  elif [ "$STATUS" = "False" ]; then
    echo "Pipeline falhou!"
    break
  fi

  sleep 30
done

echo "=== Esteira DevSecOps implantada com sucesso! ==="

kubectl apply -f getting-started/hackathon/deployments/prd/

echo "=== Serviço em produção! ==="

kubectl get all -n des

echo "=== Serviço em produção! ==="

kubectl get all -n prd