# Introdução

Essa é uma proposta de esteira DevSecOps desenvolvida pelo empregado **Marcus Vinício de Oliveira Braga (C120404)** com o intuito de automatizar
o processo de **integração continua (CI)** e **entrega continua (CD)** de uma aplicação JAVA. 
Informações detalhadas poderão ser obtidas através da documentação nesse mesmo diretório.

## Requirements

Docker instalado
Kubernete instalado
Terminal WSL ou Linux Nativo


### Passo a Passo

- Ative o serviço Docker e Kubernete em seu computador
- Crie uma pasta em seu diretório de desenvolvimento
- Clone o repositório https://github.com/quarkusio/quarkus-quickstarts.git
- Após finalizar o clone entre na pasta **quarkus-quickstarts**
- No terminal **WSL ou Linux Nativo**: curl -L https://marcusvinicio.github.io/hackathon2025/hackathon.tar.gz | tar -xz -C ./getting-started --strip-components=1
- Esse procedimento irá criar dentro de **getting-started** a pasta **hackathon**, a qual também estará anexada a entrega.
- No terminal **WSL ou Linux Nativo**: ./getting-started/hackathon/makefile.sh
- Esse processo desencadeará todo provisionamento da infraestrutura e a disponibilização em **ambiente de des e prd**
- **OPCIONAL::** Caso precise restaurar o ambiente, no terminal : ./getting-started/hackathon/__reset.sh