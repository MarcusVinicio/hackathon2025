#!/usr/bin/env bash
set -e

# Namespace padrão do Tekton
NAMESPACE="tekton-pipelines"

# Versões fixas
TEKTON_PIPELINES_VERSION="v0.66.0"
TEKTON_CLI_VERSION="0.36.0"

echo "Instalando Tekton Pipelines $TEKTON_PIPELINES_VERSION ..."
kubectl apply -f https://storage.googleapis.com/tekton-releases/pipeline/previous/${TEKTON_PIPELINES_VERSION}/release.yaml

echo "Aguardando pods subirem no namespace $NAMESPACE ..."
kubectl wait --for=condition=available --timeout=600s deployment --all -n $NAMESPACE

echo "Tekton instalado com sucesso!"
