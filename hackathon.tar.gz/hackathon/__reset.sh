#!/bin/bash
set -euo pipefail

echo "=== RESET COMPLETO DA ESTEIRA DEVSECOPS ==="

############################################
# 1. Apagar Namespaces
############################################
echo "=== Apagando namespaces ==="
kubectl delete namespace des --ignore-not-found
kubectl delete namespace prd --ignore-not-found
kubectl delete namespace observability --ignore-not-found

############################################
# 2. Remover PVCs (caso tenham ficado órfãos)
############################################
echo "=== Removendo PVCs órfãos ==="
kubectl get pvc --all-namespaces | grep -E "des|prd|observability" || true

kubectl delete pvc --all -n des --ignore-not-found
kubectl delete pvc --all -n prd --ignore-not-found
kubectl delete pvc --all -n observability --ignore-not-found

############################################
# 3. Limpar imagens locais
############################################
echo "=== Limpando imagens locais do Docker ==="
docker system prune -a --volumes -f

############################################
# 4. Verificação final
############################################
echo "=== Conferindo se sobrou algo ==="
kubectl get all --all-namespaces | grep -E "des|prd|observability" || echo "Tudo removido."
docker system df

echo "=== Reset completo da esteira DevSecOps ==="
